COT_EXAMPLES = None

COT_TASK_DESC = None
PROBLEM_FORMAT_STR = """Below is an instruction that describes a task. Write a response that appropriately completes the request.

### Instruction:
{question}

### Response:
"""

SEP=""